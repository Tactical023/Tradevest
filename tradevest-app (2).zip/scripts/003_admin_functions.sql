-- Function to get total balances for admin dashboard
create or replace function get_total_balances()
returns table(
  total_balance numeric,
  total_invested numeric,
  total_profit numeric
)
language plpgsql
security definer
as $$
begin
  return query
  select 
    coalesce(sum(p.balance), 0) as total_balance,
    coalesce(sum(p.total_invested), 0) as total_invested,
    coalesce(sum(p.total_profit), 0) as total_profit
  from public.profiles p;
end;
$$;

-- Function to get user statistics
create or replace function get_user_stats()
returns table(
  total_users bigint,
  verified_users bigint,
  active_investments bigint,
  total_referrals bigint
)
language plpgsql
security definer
as $$
begin
  return query
  select 
    (select count(*) from public.profiles) as total_users,
    (select count(*) from public.profiles where is_verified = true) as verified_users,
    (select count(*) from public.investments where status = 'active') as active_investments,
    (select count(*) from public.referrals) as total_referrals;
end;
$$;

-- Create admin user (run this manually with your admin email)
-- insert into auth.users (email, encrypted_password, email_confirmed_at, created_at, updated_at)
-- values ('admin@tradevest.com', crypt('admin123', gen_salt('bf')), now(), now(), now());

-- Update profile to make admin
-- update public.profiles set is_admin = true where email = 'admin@tradevest.com';
