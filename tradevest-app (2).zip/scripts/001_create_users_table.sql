-- Create users profile table with trading-specific fields
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique not null,
  full_name text,
  username text unique,
  phone text,
  country text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
  is_admin boolean default false,
  is_verified boolean default false,
  balance decimal(15,2) default 0.00,
  total_invested decimal(15,2) default 0.00,
  total_profit decimal(15,2) default 0.00,
  referral_code text unique,
  referred_by uuid references public.profiles(id),
  avatar_url text
);

-- Enable RLS
alter table public.profiles enable row level security;

-- Create policies for profiles
create policy "profiles_select_own"
  on public.profiles for select
  using (auth.uid() = id);

create policy "profiles_insert_own"
  on public.profiles for insert
  with check (auth.uid() = id);

create policy "profiles_update_own"
  on public.profiles for update
  using (auth.uid() = id);

create policy "profiles_delete_own"
  on public.profiles for delete
  using (auth.uid() = id);

-- Admin can view all profiles
create policy "profiles_admin_select_all"
  on public.profiles for select
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and is_admin = true
    )
  );

-- Create investments table
create table if not exists public.investments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade not null,
  plan_name text not null,
  amount decimal(15,2) not null,
  roi_percentage decimal(5,2) not null,
  duration_days integer not null,
  start_date timestamp with time zone default timezone('utc'::text, now()) not null,
  end_date timestamp with time zone not null,
  status text default 'active' check (status in ('active', 'completed', 'cancelled')),
  daily_profit decimal(15,2) default 0.00,
  total_earned decimal(15,2) default 0.00,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS for investments
alter table public.investments enable row level security;

-- Investment policies
create policy "investments_select_own"
  on public.investments for select
  using (auth.uid() = user_id);

create policy "investments_insert_own"
  on public.investments for insert
  with check (auth.uid() = user_id);

create policy "investments_update_own"
  on public.investments for update
  using (auth.uid() = user_id);

-- Admin can view all investments
create policy "investments_admin_select_all"
  on public.investments for select
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and is_admin = true
    )
  );

-- Create referrals table
create table if not exists public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid references public.profiles(id) on delete cascade not null,
  referred_id uuid references public.profiles(id) on delete cascade not null,
  reward_amount decimal(15,2) default 0.00,
  status text default 'pending' check (status in ('pending', 'completed')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS for referrals
alter table public.referrals enable row level security;

-- Referral policies
create policy "referrals_select_own"
  on public.referrals for select
  using (auth.uid() = referrer_id or auth.uid() = referred_id);

create policy "referrals_insert_own"
  on public.referrals for insert
  with check (auth.uid() = referrer_id);

-- Admin can view all referrals
create policy "referrals_admin_select_all"
  on public.referrals for select
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and is_admin = true
    )
  );
