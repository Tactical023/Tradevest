"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import BottomNavigation from "@/components/bottom-navigation"
import { ArrowLeft, Search, Filter, Star } from "lucide-react"
import Link from "next/link"
import { ProtectedRoute } from "@/components/protected-route"

export default function InvestingPage() {
  const [activeTab, setActiveTab] = useState("trending")
  const [searchQuery, setSearchQuery] = useState("")

  const trendingTokens = [
    {
      symbol: "SOL",
      name: "Solana",
      price: "226.04",
      change: "+1.74%",
      positive: true,
      volume: "170.34M",
      marketCap: "108.2B",
      category: "Layer 1",
    },
    {
      symbol: "BNB",
      name: "BNB Chain",
      price: "712.45",
      change: "+2.31%",
      positive: true,
      volume: "1.2B",
      marketCap: "102.8B",
      category: "Exchange",
    },
    {
      symbol: "JUP",
      name: "Jupiter",
      price: "1.23",
      change: "+7.89%",
      positive: true,
      volume: "67.8M",
      marketCap: "1.6B",
      category: "DeFi",
    },
    {
      symbol: "RAY",
      name: "Raydium",
      price: "5.67",
      change: "+4.32%",
      positive: true,
      volume: "45.6M",
      marketCap: "1.2B",
      category: "DEX",
    },
    {
      symbol: "ORCA",
      name: "Orca",
      price: "4.21",
      change: "+6.78%",
      positive: true,
      volume: "23.4M",
      marketCap: "890M",
      category: "DEX",
    },
    {
      symbol: "SAMO",
      name: "Samoyedcoin",
      price: "0.0234",
      change: "+12.45%",
      positive: true,
      volume: "12.3M",
      marketCap: "234M",
      category: "Meme",
    },
    {
      symbol: "CAKE",
      name: "PancakeSwap",
      price: "2.87",
      change: "+3.21%",
      positive: true,
      volume: "89.2M",
      marketCap: "1.8B",
      category: "DeFi",
    },
    {
      symbol: "ALPACA",
      name: "Alpaca Finance",
      price: "0.456",
      change: "+8.91%",
      positive: true,
      volume: "15.6M",
      marketCap: "156M",
      category: "DeFi",
    },
    {
      symbol: "BAKE",
      name: "BakeryToken",
      price: "0.789",
      change: "+5.67%",
      positive: true,
      volume: "34.2M",
      marketCap: "234M",
      category: "DeFi",
    },
    {
      symbol: "SRM",
      name: "Serum",
      price: "0.234",
      change: "-2.34%",
      positive: false,
      volume: "18.9M",
      marketCap: "123M",
      category: "DEX",
    },
  ]

  const investmentCategories = [
    { name: "DeFi", count: "2,456", change: "+12.3%", positive: true },
    { name: "Layer 1", count: "89", change: "+8.7%", positive: true },
    { name: "Meme Coins", count: "1,234", change: "+45.6%", positive: true },
    { name: "Gaming", count: "567", change: "+23.4%", positive: true },
    { name: "NFT", count: "345", change: "-5.2%", positive: false },
    { name: "Metaverse", count: "234", change: "+15.8%", positive: true },
  ]

  const topGainers = trendingTokens.filter((token) => Number.parseFloat(token.change) > 5).slice(0, 5)
  const topLosers = trendingTokens.filter((token) => Number.parseFloat(token.change) < 0).slice(0, 3)

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-slate-950 text-white pb-20">
        {/* Header */}
        <div className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur border-b border-slate-800">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <Link href="/">
                <Button variant="ghost" size="sm" className="p-2">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <h1 className="text-xl font-bold">Investing</h1>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm">
                <Filter className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="sm">
                <Star className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="px-4 pb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search tokens, projects..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-slate-900/50 border-slate-700 text-sm"
              />
            </div>
          </div>

          {/* Tabs */}
          <div className="flex px-4 pb-2">
            {[
              { id: "trending", label: "Trending" },
              { id: "gainers", label: "Top Gainers" },
              { id: "categories", label: "Categories" },
              { id: "watchlist", label: "Watchlist" },
            ].map((tab) => (
              <Button
                key={tab.id}
                variant="ghost"
                size="sm"
                onClick={() => setActiveTab(tab.id)}
                className={`text-xs px-3 py-2 ${
                  activeTab === tab.id
                    ? "text-amber-400 border-b-2 border-amber-400 rounded-none"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {tab.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {activeTab === "trending" && (
            <>
              {/* Market Overview */}
              <Card className="p-4 bg-slate-900/50 border-slate-800">
                <h3 className="font-semibold mb-3 text-sm">Market Overview</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-lg font-bold text-emerald-400">+12.3%</div>
                    <div className="text-xs text-slate-400">24h Change</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold">$2.8T</div>
                    <div className="text-xs text-slate-400">Market Cap</div>
                  </div>
                </div>
              </Card>

              {/* Trending Tokens */}
              <Card className="p-4 bg-slate-900/50 border-slate-800">
                <h3 className="font-semibold mb-3 text-sm">Trending Now</h3>
                <div className="space-y-2">
                  {trendingTokens.slice(0, 8).map((token, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-800/30 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-slate-700 to-slate-800 rounded-full flex items-center justify-center border border-slate-600">
                          <span className="text-xs font-bold">{token.symbol.slice(0, 2)}</span>
                        </div>
                        <div>
                          <div className="font-medium text-sm">{token.symbol}</div>
                          <div className="text-xs text-slate-400">{token.category}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-sm">${token.price}</div>
                        <Badge
                          variant={token.positive ? "default" : "destructive"}
                          className={`text-xs ${
                            token.positive
                              ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                              : "bg-red-500/20 text-red-400 border-red-500/30"
                          }`}
                        >
                          {token.change}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </>
          )}

          {activeTab === "gainers" && (
            <Card className="p-4 bg-slate-900/50 border-slate-800">
              <h3 className="font-semibold mb-3 text-sm">Top Gainers (24h)</h3>
              <div className="space-y-2">
                {topGainers.map((token, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-800/30 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-6 h-6 bg-emerald-500/20 rounded-full flex items-center justify-center text-emerald-400 text-xs font-bold">
                        {index + 1}
                      </div>
                      <div className="w-8 h-8 bg-gradient-to-br from-slate-700 to-slate-800 rounded-full flex items-center justify-center border border-slate-600">
                        <span className="text-xs font-bold">{token.symbol.slice(0, 2)}</span>
                      </div>
                      <div>
                        <div className="font-medium text-sm">{token.symbol}</div>
                        <div className="text-xs text-slate-400">Vol: {token.volume}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium text-sm">${token.price}</div>
                      <Badge className="text-xs bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                        {token.change}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {activeTab === "categories" && (
            <div className="grid grid-cols-2 gap-3">
              {investmentCategories.map((category, index) => (
                <Card
                  key={index}
                  className="p-3 bg-slate-900/50 border-slate-800 hover:bg-slate-800/30 transition-colors cursor-pointer"
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-sm">{category.name}</h4>
                    <Badge
                      variant={category.positive ? "default" : "destructive"}
                      className={`text-xs ${
                        category.positive
                          ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                          : "bg-red-500/20 text-red-400 border-red-500/30"
                      }`}
                    >
                      {category.change}
                    </Badge>
                  </div>
                  <div className="text-xs text-slate-400">{category.count} tokens</div>
                </Card>
              ))}
            </div>
          )}

          {activeTab === "watchlist" && (
            <Card className="p-6 bg-slate-900/50 border-slate-800 text-center">
              <Star className="w-12 h-12 mx-auto mb-3 text-slate-600" />
              <h3 className="font-semibold mb-2">Your Watchlist is Empty</h3>
              <p className="text-sm text-slate-400 mb-4">Add tokens to track their performance</p>
              <Button
                size="sm"
                className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
              >
                Browse Tokens
              </Button>
            </Card>
          )}
        </div>

        <BottomNavigation />
      </div>
    </ProtectedRoute>
  )
}
