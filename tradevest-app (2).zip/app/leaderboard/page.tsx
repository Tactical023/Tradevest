"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Trophy } from "lucide-react"
import Link from "next/link"
import BottomNavigation from "@/components/bottom-navigation"

export default function LeaderboardPage() {
  const leaderboard = [
    { rank: 1, user: "Tr***er", points: "45,670", prize: "$5,000", avatar: "🥇" },
    { rank: 2, user: "Cr***oK", points: "42,340", prize: "$3,000", avatar: "🥈" },
    { rank: 3, user: "Bi***nF", points: "38,920", prize: "$2,000", avatar: "🥉" },
    { rank: 4, user: "Et***um", points: "35,680", prize: "$1,500", avatar: "4" },
    { rank: 5, user: "So***na", points: "32,450", prize: "$1,000", avatar: "5" },
    { rank: 6, user: "Ad***ex", points: "29,870", prize: "$800", avatar: "6" },
    { rank: 7, user: "Po***on", points: "27,340", prize: "$600", avatar: "7" },
    { rank: 8, user: "Li***nk", points: "25,120", prize: "$400", avatar: "8" },
    { rank: 9, user: "Do***ge", points: "23,560", prize: "$300", avatar: "9" },
    { rank: 10, user: "Sh***ba", points: "21,890", prize: "$200", avatar: "10" },
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-white pb-20">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur border-b border-slate-800">
        <div className="flex items-center gap-4 p-3">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <h1 className="text-lg font-bold">Leaderboard</h1>
        </div>
      </div>

      <div className="space-y-4">
        {/* Campaign Info */}
        <div className="p-3">
          <Card className="p-4 bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 text-white border-0">
            <div className="text-center">
              <Trophy className="w-8 h-8 mx-auto mb-2" />
              <h2 className="text-lg font-bold mb-2">$200K USD Campaign</h2>
              <p className="text-sm opacity-90 mb-3">Compete with traders worldwide for massive USD prizes</p>
              <div className="grid grid-cols-3 gap-3 text-sm">
                <div>
                  <div className="font-bold text-xl">15,847</div>
                  <div className="opacity-90">Participants</div>
                </div>
                <div>
                  <div className="font-bold text-xl">$200K</div>
                  <div className="opacity-90">Total Prize</div>
                </div>
                <div>
                  <div className="font-bold text-xl">12D</div>
                  <div className="opacity-90">Time Left</div>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Top 3 Podium */}
        <div className="px-3">
          <div className="flex items-end justify-center gap-2 mb-4">
            {/* 2nd Place */}
            <div className="flex flex-col items-center">
              <div className="w-16 h-20 bg-gradient-to-t from-slate-600 to-slate-400 rounded-t-lg flex items-end justify-center pb-2">
                <div className="text-center">
                  <div className="text-2xl mb-1">🥈</div>
                  <div className="text-xs font-bold text-white">2nd</div>
                </div>
              </div>
              <div className="text-center mt-2">
                <div className="font-bold text-sm text-white">{leaderboard[1].user}</div>
                <div className="text-xs text-slate-400">{leaderboard[1].points} pts</div>
                <div className="text-xs font-bold text-emerald-400">{leaderboard[1].prize}</div>
              </div>
            </div>

            {/* 1st Place */}
            <div className="flex flex-col items-center">
              <div className="w-16 h-24 bg-gradient-to-t from-amber-600 to-yellow-400 rounded-t-lg flex items-end justify-center pb-2">
                <div className="text-center">
                  <div className="text-2xl mb-1">🥇</div>
                  <div className="text-xs font-bold text-black">1st</div>
                </div>
              </div>
              <div className="text-center mt-2">
                <div className="font-bold text-sm text-white">{leaderboard[0].user}</div>
                <div className="text-xs text-slate-400">{leaderboard[0].points} pts</div>
                <div className="text-xs font-bold text-emerald-400">{leaderboard[0].prize}</div>
              </div>
            </div>

            {/* 3rd Place */}
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 bg-gradient-to-t from-amber-700 to-amber-500 rounded-t-lg flex items-end justify-center pb-2">
                <div className="text-center">
                  <div className="text-2xl mb-1">🥉</div>
                  <div className="text-xs font-bold text-white">3rd</div>
                </div>
              </div>
              <div className="text-center mt-2">
                <div className="font-bold text-sm text-white">{leaderboard[2].user}</div>
                <div className="text-xs text-slate-400">{leaderboard[2].points} pts</div>
                <div className="text-xs font-bold text-emerald-400">{leaderboard[2].prize}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Full Leaderboard */}
        <div className="px-3 space-y-2">
          <h3 className="font-semibold text-white text-sm mb-3">Full Rankings</h3>

          {leaderboard.map((entry, index) => (
            <Card key={index} className="p-3 bg-slate-900/50 border-slate-700 hover:bg-slate-800/50 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                      entry.rank <= 3
                        ? "bg-gradient-to-r from-amber-400 to-yellow-600 text-black"
                        : "bg-slate-700 text-slate-300"
                    }`}
                  >
                    {entry.rank <= 3 ? entry.avatar : `#${entry.rank}`}
                  </div>
                  <div>
                    <div className="font-medium text-white text-sm">{entry.user}</div>
                    <div className="text-xs text-slate-400">{entry.points} points</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-emerald-400 text-sm">{entry.prize}</div>
                  <div className="text-xs text-slate-400">Prize</div>
                </div>
              </div>
            </Card>
          ))}

          {/* Your Position */}
          <Card className="p-3 bg-amber-500/10 border-amber-500/30 mt-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-500/30 flex items-center justify-center font-bold text-sm text-amber-400">
                  #156
                </div>
                <div>
                  <div className="font-medium text-amber-400 text-sm">You</div>
                  <div className="text-xs text-slate-400">2,450 points</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-bold text-emerald-400 text-sm">$50</div>
                <div className="text-xs text-slate-400">Current Prize</div>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <BottomNavigation />
    </div>
  )
}
