"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Gift, Trophy, Clock, Target } from "lucide-react"
import Link from "next/link"
import BottomNavigation from "@/components/bottom-navigation"

export default function RewardsPage() {
  const [activeTab, setActiveTab] = useState("campaigns")

  const campaigns = [
    {
      title: "$200,000 USD Mega Campaign",
      description: "Join our biggest rewards campaign ever with real USD prizes",
      totalPrize: "$200,000 USD",
      participants: "15,847",
      timeLeft: "12D 08H 45M 23S",
      userPoints: "2,450",
      userRank: "#156",
      tasks: [
        { name: "Daily Login", points: "50", completed: true },
        { name: "Complete 3 Trades", points: "200", completed: false },
        { name: "Refer 1 Friend", points: "500", completed: false },
        { name: "Deposit $100+", points: "1000", completed: true },
      ],
    },
  ]

  const leaderboard = [
    { rank: 1, user: "Tr***er", points: "45,670", prize: "$5,000" },
    { rank: 2, user: "Cr***oK", points: "42,340", prize: "$3,000" },
    { rank: 3, user: "Bi***nF", points: "38,920", prize: "$2,000" },
    { rank: 4, user: "Et***um", points: "35,680", prize: "$1,500" },
    { rank: 5, user: "So***na", points: "32,450", prize: "$1,000" },
    { rank: 156, user: "You", points: "2,450", prize: "$50", isUser: true },
  ]

  const vouchers = [
    {
      title: "Trading Fee Discount",
      description: "50% off trading fees for 30 days",
      value: "$25 Value",
      expiry: "30 days",
      available: 5,
      cost: "1,000 points",
    },
    {
      title: "VIP Access Pass",
      description: "Premium features access for 1 month",
      value: "$100 Value",
      expiry: "60 days",
      available: 2,
      cost: "5,000 points",
    },
    {
      title: "Cash Bonus",
      description: "Direct USD deposit to your account",
      value: "$50 USD",
      expiry: "No expiry",
      available: 10,
      cost: "2,500 points",
    },
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-white pb-20">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur border-b border-slate-800">
        <div className="flex items-center gap-4 p-3">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <h1 className="text-lg font-bold">Rewards Hub</h1>
        </div>
      </div>

      <div className="space-y-4">
        {/* Points Summary */}
        <div className="p-3">
          <Card className="p-4 bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 text-white border-0">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold">Your Points</h2>
                <div className="text-2xl font-bold">2,450 PTS</div>
                <p className="text-sm opacity-90">Rank #156 globally</p>
              </div>
              <div className="text-right">
                <Trophy className="w-8 h-8 mb-2" />
                <Button className="bg-white/20 hover:bg-white/30 text-white border-0 text-sm">View History</Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="px-3">
          <div className="flex gap-1 bg-slate-800/50 rounded-lg p-1">
            {[
              { id: "campaigns", icon: Target, label: "Campaigns" },
              { id: "leaderboard", icon: Trophy, label: "Leaderboard" },
              { id: "vouchers", icon: Gift, label: "Vouchers" },
            ].map((tab) => (
              <Button
                key={tab.id}
                variant={activeTab === tab.id ? "default" : "ghost"}
                size="sm"
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex items-center gap-1 text-xs ${
                  activeTab === tab.id ? "bg-slate-700 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                <tab.icon className="w-3 h-3" />
                <span>{tab.label}</span>
              </Button>
            ))}
          </div>
        </div>

        {/* Campaigns Tab */}
        {activeTab === "campaigns" && (
          <div className="px-3 space-y-4">
            {campaigns.map((campaign, index) => (
              <Card key={index} className="p-4 bg-slate-900/50 border-slate-700">
                <div className="space-y-4">
                  <div className="text-center">
                    <h3 className="text-lg font-bold text-white mb-2">{campaign.title}</h3>
                    <p className="text-sm text-slate-300 mb-3">{campaign.description}</p>

                    <div className="text-3xl font-bold text-amber-400 mb-2">{campaign.totalPrize}</div>

                    <div className="grid grid-cols-3 gap-3 text-sm">
                      <div>
                        <div className="text-slate-400">Participants</div>
                        <div className="font-bold text-white">{campaign.participants}</div>
                      </div>
                      <div>
                        <div className="text-slate-400">Your Points</div>
                        <div className="font-bold text-emerald-400">{campaign.userPoints}</div>
                      </div>
                      <div>
                        <div className="text-slate-400">Your Rank</div>
                        <div className="font-bold text-purple-400">{campaign.userRank}</div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-2 text-sm">
                    <Clock className="w-4 h-4 text-slate-400" />
                    <span className="text-slate-400">Ends in:</span>
                    <span className="font-mono font-bold text-white">{campaign.timeLeft}</span>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-semibold text-white text-sm">Available Tasks</h4>
                    {campaign.tasks.map((task, taskIndex) => (
                      <div key={taskIndex} className="flex items-center justify-between p-2 bg-slate-800/50 rounded-lg">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                              task.completed ? "border-emerald-400 bg-emerald-400" : "border-slate-600"
                            }`}
                          >
                            {task.completed && <div className="w-2 h-2 bg-white rounded-full" />}
                          </div>
                          <span className="text-sm text-white">{task.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-amber-400">+{task.points}</span>
                          {!task.completed && (
                            <Button size="sm" className="bg-amber-500 text-black hover:bg-amber-400 text-xs px-2 py-1">
                              Do Task
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Leaderboard Tab */}
        {activeTab === "leaderboard" && (
          <div className="px-3 space-y-3">
            <h3 className="font-semibold text-white text-sm">Global Leaderboard</h3>

            {leaderboard.map((entry, index) => (
              <Card
                key={index}
                className={`p-3 ${entry.isUser ? "bg-amber-500/10 border-amber-500/30" : "bg-slate-900/50 border-slate-700"}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                        entry.rank <= 3
                          ? "bg-gradient-to-r from-amber-400 to-yellow-600 text-black"
                          : entry.isUser
                            ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                            : "bg-slate-700 text-slate-300"
                      }`}
                    >
                      {entry.rank <= 3 ? (entry.rank === 1 ? "🥇" : entry.rank === 2 ? "🥈" : "🥉") : `#${entry.rank}`}
                    </div>
                    <div>
                      <div className={`font-medium ${entry.isUser ? "text-amber-400" : "text-white"}`}>
                        {entry.user}
                      </div>
                      <div className="text-xs text-slate-400">{entry.points} points</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-emerald-400 text-sm">{entry.prize}</div>
                    <div className="text-xs text-slate-400">Prize</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Vouchers Tab */}
        {activeTab === "vouchers" && (
          <div className="px-3 space-y-3">
            <h3 className="font-semibold text-white text-sm">Redeem Vouchers</h3>

            {vouchers.map((voucher, index) => (
              <Card key={index} className="p-3 bg-slate-900/50 border-slate-700">
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                        <Gift className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h4 className="font-medium text-white text-sm">{voucher.title}</h4>
                        <p className="text-xs text-slate-400 leading-relaxed">{voucher.description}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 text-xs">
                            {voucher.value}
                          </Badge>
                          <span className="text-xs text-slate-400">• {voucher.available} available</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs text-slate-400">Cost</div>
                      <div className="font-bold text-amber-400 text-sm">{voucher.cost}</div>
                    </div>
                    <div>
                      <div className="text-xs text-slate-400">Expires in</div>
                      <div className="font-medium text-white text-sm">{voucher.expiry}</div>
                    </div>
                    <Button
                      size="sm"
                      className="bg-purple-600 hover:bg-purple-700 text-white text-xs px-3 py-1"
                      disabled={voucher.cost.replace(/[^\d]/g, "") > "2450"}
                    >
                      Redeem
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      <BottomNavigation />
    </div>
  )
}
