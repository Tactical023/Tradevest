"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import BottomNavigation from "@/components/bottom-navigation"
import {
  ArrowLeft,
  Users,
  Gift,
  Copy,
  Target,
  BookOpen,
  Flag,
  MessageCircle,
  Phone,
  Instagram,
  Twitter,
  X,
} from "lucide-react"
import Link from "next/link"

export default function ReferralPage() {
  const [activeTab, setActiveTab] = useState("referrals")
  const [referralCode] = useState("GRO_20338_HYYKB")
  const [referralLink] = useState("https://www...YYKB")

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const tasks = [
    {
      id: 1,
      title: "Invite new users to trade > $100",
      subtitle: "Spot & Convert",
      description:
        "Ensure you have an ongoing round before your friends register and that your friends complete the tasks during the same round they're invited. Otherwise, you won't receive a boost from their task completions.",
      reward: "Up to $50 per referral",
      progress: 0,
      total: 100,
      completed: false,
    },
  ]

  const rewards = [
    {
      title: "Earn $4 USDT! Complete Tasks to Claim Reward",
      progress: 0,
      total: 100,
      reward: "$4 USDT Token Voucher",
      timeLeft: "07D : 07H : 40M",
      type: "task",
    },
    {
      title: "Deposit at least $10 USDT via Wallet to Earn $1 USDT",
      progress: 0,
      total: 10,
      reward: "$1 USDT Token Voucher",
      timeLeft: "09D : 18H : 52M",
      type: "deposit",
    },
  ]

  const earnTogether = {
    title: "$200,000 USD CAMPAIGN AWAITS!",
    subtitle: "Join TradeVest's mega referral campaign and earn real USD rewards.",
    hashtag: "#TradeVestEarnTogether",
    progress: 44.43,
    accumulated: "$1,245.67 USD",
    recentActivity: ["User 7******1 has received $50 USD reward.", "5*****0 has received $100 USD bonus."],
    timeLeft: "9 D : 23 H : 58 M",
  }

  const leaderboard = [
    { rank: 1, user: "Tr***er", referrals: 156, rewards: "$2,450" },
    { rank: 2, user: "Cr***oK", referrals: 134, rewards: "$2,100" },
    { rank: 3, user: "Bi***nF", referrals: 128, rewards: "$1,980" },
    { rank: 4, user: "Et***um", referrals: 98, rewards: "$1,560" },
    { rank: 5, user: "So***na", referrals: 87, rewards: "$1,390" },
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-white pb-20">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur border-b border-slate-800">
        <div className="flex items-center justify-between p-3">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <h1 className="text-lg font-bold">EARN TOGETHER</h1>
          </div>
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        {/* Campaign Banner */}
        <div className="p-3">
          <Card className="p-4 bg-gradient-to-br from-slate-800 via-slate-900 to-black border-slate-700 relative overflow-hidden">
            <div className="relative z-10">
              <div className="text-amber-400 text-xs font-medium mb-2">Time-Limited ▼</div>

              <h2 className="text-xl font-bold mb-3 text-center">EARN TOGETHER</h2>
              <p className="text-center text-slate-300 mb-4 text-sm">
                Invite friends to earn USD rewards —<br />
                Real money, real profits!
              </p>

              {/* Reward Tiers */}
              <div className="flex justify-center mb-4">
                <div className="flex items-center gap-1">
                  {[
                    { amount: "$20", active: true },
                    { amount: "$50", active: false },
                    { amount: "$100", active: false },
                    { amount: "$100", active: false, special: true },
                  ].map((tier, index) => (
                    <div key={index} className="flex flex-col items-center">
                      <div
                        className={`w-6 h-6 rounded border-2 flex items-center justify-center text-xs ${
                          tier.active ? "border-amber-400 bg-amber-400/20" : "border-slate-600 bg-slate-800"
                        }`}
                      >
                        {tier.special ? <Gift className="w-3 h-3" /> : "💰"}
                      </div>
                      <div className="text-xs mt-1 text-slate-400">{tier.amount}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Progress Circle */}
              <div className="flex items-center justify-center mb-4">
                <div className="relative w-32 h-32">
                  <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 120 120">
                    <circle cx="60" cy="60" r="45" stroke="rgba(255,255,255,0.1)" strokeWidth="5" fill="transparent" />
                    <circle
                      cx="60"
                      cy="60"
                      r="45"
                      stroke="#fbbf24"
                      strokeWidth="5"
                      fill="transparent"
                      strokeDasharray={`${(earnTogether.progress / 100) * 283} 283`}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <div className="text-2xl font-bold">{earnTogether.progress}%</div>
                    <div className="text-xs text-slate-400">Accumulated</div>
                  </div>
                </div>
              </div>

              <div className="text-center mb-3">
                <div className="text-lg font-bold mb-2">{earnTogether.accumulated}</div>
                <Button className="bg-amber-500 text-black hover:bg-amber-400 px-6 text-sm">Withdraw</Button>
              </div>

              <div className="space-y-1 text-xs text-slate-400 mb-3">
                {earnTogether.recentActivity.map((activity, index) => (
                  <div key={index} className="text-center">
                    {activity}
                  </div>
                ))}
              </div>

              <div className="text-center">
                <div className="text-xs text-slate-400">Current round time left:</div>
                <div className="font-mono font-bold text-sm">{earnTogether.timeLeft}</div>
              </div>
            </div>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="px-3">
          <div className="flex gap-1 bg-slate-800/50 rounded-lg p-1">
            {[
              { id: "referrals", icon: Users, label: "Referrals" },
              { id: "rewards", icon: Gift, label: "Rewards" },
              { id: "rules", icon: BookOpen, label: "Rules" },
              { id: "progress", icon: Flag, label: "Progress" },
            ].map((tab) => (
              <Button
                key={tab.id}
                variant={activeTab === tab.id ? "default" : "ghost"}
                size="sm"
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex items-center gap-1 text-xs ${
                  activeTab === tab.id ? "bg-slate-700 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                <tab.icon className="w-3 h-3" />
                <span>{tab.label}</span>
              </Button>
            ))}
          </div>
        </div>

        {/* Tasks Section */}
        {activeTab === "referrals" && (
          <div className="px-3 space-y-4">
            <div className="text-center">
              <h2 className="text-xl font-bold mb-2">TASKS</h2>
            </div>

            {tasks.map((task, index) => (
              <Card key={index} className="p-3 bg-slate-900/50 border-slate-700">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center border border-slate-600">
                      <Users className="w-5 h-5 text-slate-400" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-white text-sm">
                        Task {task.id}: {task.title}
                      </h4>
                      <Badge className="mt-1 text-xs bg-amber-500/20 text-amber-400 border-amber-500/30">
                        {task.subtitle}
                      </Badge>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 p-2 rounded-lg">
                    <p className="text-xs text-slate-300 leading-relaxed">{task.description}</p>
                  </div>

                  <Button className="w-full bg-amber-500 text-black hover:bg-amber-400 text-sm py-2">Invite</Button>
                </div>
              </Card>
            ))}

            <Button className="w-full bg-amber-500 text-black hover:bg-amber-400 py-4 text-sm font-bold">
              Invite Friends
            </Button>
          </div>
        )}

        {/* Share Section */}
        <div className="px-3 pb-4">
          <Card className="p-3 bg-slate-900/50 border-slate-700">
            <h3 className="font-semibold mb-3 text-white text-sm">Share</h3>
            <div className="space-y-2">
              <div>
                <label className="text-xs text-slate-400">Referral ID</label>
                <div className="flex items-center gap-2 mt-1">
                  <Input value={referralCode} readOnly className="bg-slate-800 border-slate-600 text-white text-sm" />
                  <Button
                    size="sm"
                    onClick={() => copyToClipboard(referralCode)}
                    className="bg-slate-700 hover:bg-slate-600"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>
              <div>
                <label className="text-xs text-slate-400">Referral Link</label>
                <div className="flex items-center gap-2 mt-1">
                  <Input value={referralLink} readOnly className="bg-slate-800 border-slate-600 text-white text-sm" />
                  <Button
                    size="sm"
                    onClick={() => copyToClipboard(referralLink)}
                    className="bg-slate-700 hover:bg-slate-600"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Social Share Buttons */}
            <div className="grid grid-cols-5 gap-2 mt-4">
              {[
                { icon: MessageCircle, label: "Contact", color: "bg-slate-700" },
                { icon: MessageCircle, label: "Telegram", color: "bg-blue-500" },
                { icon: Phone, label: "WhatsApp", color: "bg-green-600" },
                { icon: Twitter, label: "X", color: "bg-black" },
                { icon: Instagram, label: "Instagram", color: "bg-pink-500" },
              ].map((platform, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="flex flex-col gap-1 h-12 bg-slate-800/50 border-slate-600 hover:bg-slate-700/50"
                >
                  <div className={`w-4 h-4 rounded-full ${platform.color} flex items-center justify-center`}>
                    <platform.icon className="w-2 h-2 text-white" />
                  </div>
                  <span className="text-xs text-slate-300">{platform.label}</span>
                </Button>
              ))}
            </div>
          </Card>
        </div>

        {/* Content based on active tab */}
        {activeTab === "rewards" && (
          <div className="px-4 pb-24 space-y-4">
            <h3 className="font-semibold text-white">Get Rewards</h3>
            <h4 className="text-slate-400">Explore More</h4>

            {rewards.map((reward, index) => (
              <Card key={index} className="p-4 bg-slate-900/50 border-slate-700">
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center border border-slate-600">
                      {reward.type === "task" ? (
                        <Target className="w-6 h-6 text-slate-400" />
                      ) : (
                        <ArrowLeft className="w-6 h-6 text-slate-400 rotate-180" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-white">{reward.title}</h4>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-sm text-slate-400">Progress</span>
                        <span className="text-sm font-medium text-white">
                          {reward.progress}/{reward.total} {reward.type === "task" ? "USDT" : "USDT"}
                        </span>
                      </div>
                      <div className="w-full bg-slate-800 rounded-full h-2 mt-2">
                        <div
                          className="bg-emerald-500 h-2 rounded-full"
                          style={{ width: `${(reward.progress / reward.total) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-slate-400">Reward</div>
                      <div className="font-medium text-amber-400">{reward.reward}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-slate-400">Time Left to Complete</div>
                      <div className="font-mono font-bold text-white">{reward.timeLeft}</div>
                    </div>
                  </div>

                  <Button className="w-full bg-amber-500 text-black hover:bg-amber-400">Do Task</Button>
                </div>
              </Card>
            ))}
          </div>
        )}

        {activeTab === "rules" && (
          <div className="px-4 pb-24 space-y-4">
            <h3 className="font-semibold text-white">Campaign Rules</h3>

            <Card className="p-4 bg-slate-900/50 border-slate-700">
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2 text-white">Eligibility</h4>
                  <ul className="text-sm text-slate-300 space-y-1 list-disc list-inside">
                    <li>Must be a verified TradeVest user</li>
                    <li>Complete KYC verification</li>
                    <li>Minimum account age of 7 days</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-medium mb-2 text-white">Referral Requirements</h4>
                  <ul className="text-sm text-slate-300 space-y-1 list-disc list-inside">
                    <li>Referred users must register using your unique link</li>
                    <li>Complete identity verification within 30 days</li>
                    <li>Minimum trading volume of $100 within first month</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-medium mb-2 text-white">Reward Structure</h4>
                  <ul className="text-sm text-slate-300 space-y-1 list-disc list-inside">
                    <li>Base reward: $20 per qualified referral</li>
                    <li>Volume bonus: Up to $50 for high-volume traders</li>
                    <li>Monthly bonus: Extra $200 for 5+ active referrals</li>
                    <li>VIP bonus: Up to $1000 for influencers and affiliates</li>
                  </ul>
                </div>
              </div>
            </Card>
          </div>
        )}

        {activeTab === "progress" && (
          <div className="px-4 pb-24 space-y-4">
            <h3 className="font-semibold text-white">Your Progress</h3>

            {tasks.map((task, index) => (
              <Card key={index} className="p-4 bg-slate-900/50 border-slate-700">
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center border border-slate-600">
                      <Users className="w-6 h-6 text-slate-400" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-white">
                        Task {task.id}: {task.title}
                      </h4>
                      <Badge className="mt-1 text-xs bg-amber-500/20 text-amber-400 border-amber-500/30">
                        {task.subtitle}
                      </Badge>
                      <p className="text-sm text-slate-300 mt-2">{task.description}</p>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 p-3 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-slate-400">Progress</span>
                      <span className="text-sm font-medium text-white">
                        {task.progress}/{task.total}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${task.completed ? "bg-emerald-500" : "bg-amber-500"}`}
                        style={{ width: `${task.progress}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-slate-400">Reward</div>
                      <div className="font-medium text-amber-400">{task.reward}</div>
                    </div>
                    <Button
                      size="sm"
                      variant={task.completed ? "outline" : "default"}
                      disabled={task.completed}
                      className={
                        task.completed
                          ? "border-slate-600 text-slate-400"
                          : "bg-amber-500 text-black hover:bg-amber-400"
                      }
                    >
                      {task.completed ? "Completed" : "Invite"}
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      <BottomNavigation />
    </div>
  )
}
