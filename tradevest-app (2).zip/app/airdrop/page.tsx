"use client"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Clock } from "lucide-react"
import Link from "next/link"
import BottomNavigation from "@/components/bottom-navigation"

export default function AirdropPage() {
  const airdrops = [
    {
      name: "LINEA",
      totalAmount: "1,250,000 LINEA",
      usdValue: "≈ 29,187.5 USDT",
      participants: "106",
      mode: "Trade",
      timeLeft: "06D 12H 47M 09S",
      enrolled: false,
      status: "Active",
    },
    {
      name: "LINEA",
      totalAmount: "5,200,000 LINEA",
      usdValue: "≈ 121,420 USDT",
      participants: "7,582",
      mode: "Trade",
      timeLeft: "06D 08H 47M 08S",
      enrolled: true,
      status: "Ongoing",
    },
    {
      name: "AVNT",
      totalAmount: "2,800,000 AVNT",
      usdValue: "≈ 84,560 USDT",
      participants: "3,245",
      mode: "Stake",
      timeLeft: "12D 15H 32M 18S",
      enrolled: false,
      status: "Active",
    },
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-white pb-20">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur border-b border-slate-800">
        <div className="flex items-center gap-4 p-3">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <h1 className="text-lg font-bold">Launchpad</h1>
        </div>
      </div>

      <div className="space-y-4">
        {/* Header Tabs */}
        <div className="px-3">
          <div className="flex gap-2">
            <Button className="bg-amber-500 text-black hover:bg-amber-400 text-sm px-4 py-2">Promotions</Button>
            <Button variant="ghost" className="text-slate-400 hover:text-white text-sm px-4 py-2">
              Fast-changes
            </Button>
          </div>
        </div>

        {/* Airdrops List */}
        <div className="px-3 space-y-3">
          {airdrops.map((airdrop, index) => (
            <Card key={index} className="p-4 bg-slate-900/50 border-slate-700">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-sm">{airdrop.name.slice(0, 2)}</span>
                    </div>
                    <div>
                      <h3 className="font-bold text-white">{airdrop.name}</h3>
                      <div className="flex items-center gap-2">
                        <Badge
                          className={`text-xs ${
                            airdrop.status === "Ongoing"
                              ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                              : "bg-blue-500/20 text-blue-400 border-blue-500/30"
                          }`}
                        >
                          {airdrop.status}
                        </Badge>
                        {airdrop.enrolled && (
                          <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-xs">Enrolled</Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-center">
                  <div className="text-xs text-slate-400 mb-1">Total Airdrops</div>
                  <div className="text-2xl font-bold text-white">{airdrop.totalAmount}</div>
                  <div className="text-sm text-slate-400">{airdrop.usdValue}</div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="text-center">
                    <div className="text-slate-400 text-xs">Participants</div>
                    <div className="font-bold text-white">{airdrop.participants}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-slate-400 text-xs">Airdrop mode</div>
                    <div className="font-bold text-white">{airdrop.mode}</div>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-400">Ends in</span>
                  <span className="font-mono font-bold text-white">{airdrop.timeLeft}</span>
                </div>

                <Button
                  className={`w-full ${
                    airdrop.enrolled
                      ? "bg-slate-700 text-slate-400 cursor-not-allowed"
                      : "bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white"
                  }`}
                  disabled={airdrop.enrolled}
                >
                  {airdrop.enrolled ? "enrolled" : "enroll"}
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>

      <BottomNavigation />
    </div>
  )
}
