"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, PiggyBank, Filter, Search } from "lucide-react"
import Link from "next/link"
import BottomNavigation from "@/components/bottom-navigation"
import { ProtectedRoute } from "@/components/protected-route"

export default function EarningsPage() {
  const [activeTab, setActiveTab] = useState("fixed")

  const investmentPlans = [
    {
      name: "Silver",
      duration: "1 week",
      roi: "3.5%",
      roiType: "daily",
      minAmount: "$5",
      maxAmount: "$100",
      slotsAvailable: "2k",
      category: "Common Plan",
      color: "from-slate-400 to-slate-600",
    },
    {
      name: "Agate",
      duration: "15 days",
      roi: "4%",
      roiType: "daily",
      minAmount: "$20",
      maxAmount: "$1,000",
      slotsAvailable: "1k",
      category: "Common Plan",
      color: "from-purple-400 to-purple-600",
    },
    {
      name: "Golden",
      duration: "30 days",
      roi: "5%",
      roiType: "daily",
      minAmount: "$100",
      maxAmount: "$10k",
      slotsAvailable: "500",
      category: "Special Plan",
      color: "from-amber-400 to-yellow-600",
    },
    {
      name: "Sapphire",
      duration: "3 months",
      roi: "7%",
      roiType: "daily",
      minAmount: "$500",
      maxAmount: "$100k",
      slotsAvailable: "200",
      category: "Special Plan",
      color: "from-blue-400 to-blue-600",
    },
    {
      name: "Diamond",
      duration: "6 months",
      roi: "15%",
      roiType: "daily",
      minAmount: "$1,000",
      maxAmount: "$1M",
      slotsAvailable: "109",
      category: "Special Plan",
      color: "from-cyan-400 to-indigo-600",
    },
  ]

  const flexibleProducts = [
    {
      name: "HOLO",
      apr: "10.8%",
      minAmount: "10 HOLO",
      available: "Available",
      icon: "🌐",
      description: "Flexible staking with daily rewards",
      trend: "up",
    },
    {
      name: "PUMP",
      apr: "9.95%",
      minAmount: "100 PUMP",
      available: "Available",
      icon: "⚡",
      description: "High yield flexible product",
      trend: "up",
    },
    {
      name: "USDC",
      apr: "Max 7%",
      minAmount: "10 USDC",
      available: "Bonus",
      icon: "💙",
      description: "Stable coin earning with bonus",
      trend: "up",
    },
    {
      name: "USDT",
      apr: "Max 12.11%",
      minAmount: "10 USDT",
      available: "Bonus",
      icon: "💚",
      description: "Premium USDT staking rewards",
      trend: "up",
    },
    {
      name: "DOLO",
      apr: "19.67%",
      minAmount: "50 DOLO",
      available: "Available",
      icon: "🔥",
      description: "High APR flexible staking",
      trend: "up",
    },
    {
      name: "LINEA",
      apr: "1.2%",
      minAmount: "100 LINEA",
      available: "Available",
      icon: "⚪",
      description: "Layer 2 token staking",
      trend: "up",
    },
  ]

  const lockedProducts = [
    {
      name: "SPK Locked Product",
      apr: "14.9%",
      duration: "30 Days",
      minAmount: "100 SPK",
      totalStaked: "2,450,000 SPK",
      participants: "1,250",
      timeLeft: "6D 12H 47M 09S",
    },
    {
      name: "BTC Premium Lock",
      apr: "8.5%",
      duration: "90 Days",
      minAmount: "0.001 BTC",
      totalStaked: "125.67 BTC",
      participants: "890",
      timeLeft: "12D 08H 23M 15S",
    },
    {
      name: "ETH Validator Pool",
      apr: "6.8%",
      duration: "180 Days",
      minAmount: "0.1 ETH",
      totalStaked: "1,890.45 ETH",
      participants: "2,340",
      timeLeft: "3D 15H 32M 41S",
    },
  ]

  const myStakings = [
    {
      product: "USDT Bonus Plan",
      amount: "1,500 USDT",
      apr: "12.11%",
      earned: "45.67 USDT",
      status: "Active",
      type: "Flexible",
    },
    {
      product: "SPK Locked Product",
      amount: "5,000 SPK",
      apr: "14.9%",
      earned: "125.30 SPK",
      status: "Locked",
      type: "30 Days",
      timeLeft: "18D 5H 23M",
    },
    {
      product: "HOLO Flexible",
      amount: "10,000 HOLO",
      apr: "10.8%",
      earned: "89.45 HOLO",
      status: "Active",
      type: "Flexible",
    },
  ]

  const airdrops = [
    {
      name: "LINEA Airdrop",
      totalAmount: "1,250,000 LINEA",
      usdValue: "≈ 29,187.5 USDT",
      participants: "106",
      mode: "Trade",
      timeLeft: "06D 12H 47M 09S",
      enrolled: false,
    },
    {
      name: "AVNT Airdrop",
      totalAmount: "5,200,000 LINEA",
      usdValue: "≈ 121,420 USDT",
      participants: "7,582",
      mode: "Trade",
      timeLeft: "06D 08H 47M 08S",
      enrolled: true,
    },
  ]

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-slate-950 text-white pb-20">
        {/* Header */}
        <div className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur border-b border-slate-800">
          <div className="flex items-center gap-4 p-3">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <h1 className="text-lg font-bold">Vesting Plans</h1>
            <div className="ml-auto flex items-center gap-2">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <Search className="w-3 h-3" />
              </Button>
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <Filter className="w-3 h-3" />
              </Button>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {/* Hero Banner */}
          <div className="p-3">
            <Card className="p-4 bg-gradient-to-r from-emerald-500 via-green-500 to-teal-500 text-white border-0">
              <div className="text-center">
                <h2 className="text-lg font-bold mb-2">Begin Your Trading Journey</h2>
                <p className="text-sm opacity-90 leading-relaxed">
                  Zero trading experience required. Earn passive income with up to 15% daily ROI
                </p>
              </div>
            </Card>
          </div>

          {/* Category Tabs */}
          <div className="px-3">
            <div className="flex gap-2">
              {[
                { id: "fixed", label: "Fixed Plans", active: true },
                { id: "high", label: "High Profit" },
              ].map((tab) => (
                <Button
                  key={tab.id}
                  variant={tab.active ? "default" : "ghost"}
                  onClick={() => setActiveTab(tab.id)}
                  className={`text-sm px-4 py-2 ${tab.active ? "bg-white text-slate-900" : "text-slate-400 hover:text-white"}`}
                >
                  {tab.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Investment Plans */}
          <div className="px-3 space-y-3">
            {investmentPlans.map((plan, index) => (
              <Card
                key={index}
                className="p-4 bg-slate-900/50 border-slate-700 hover:bg-slate-800/50 transition-colors"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 bg-gradient-to-br ${plan.color} rounded-full flex items-center justify-center text-white font-bold text-sm`}
                      >
                        {plan.name[0]}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-white">{plan.name}</h3>
                          <Badge
                            className={`text-xs px-2 py-0 ${plan.category === "Special Plan" ? "bg-amber-500/20 text-amber-400 border-amber-500/30" : "bg-slate-500/20 text-slate-400 border-slate-500/30"}`}
                          >
                            {plan.category}
                          </Badge>
                        </div>
                        <p className="text-xs text-slate-400">{plan.slotsAvailable} slots available</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-emerald-400">{plan.roi}</div>
                      <div className="text-xs text-slate-400">{plan.roiType}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-sm">
                    <div>
                      <div className="text-slate-400 text-xs">Duration</div>
                      <div className="font-medium text-white">{plan.duration}</div>
                    </div>
                    <div>
                      <div className="text-slate-400 text-xs">Min Amount</div>
                      <div className="font-medium text-white">{plan.minAmount}</div>
                    </div>
                    <div>
                      <div className="text-slate-400 text-xs">Max Amount</div>
                      <div className="font-medium text-white">{plan.maxAmount}</div>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white border-0 text-sm py-2">
                    Invest Now - {plan.roi} Daily ROI
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          {/* Bottom Info */}
          <div className="px-3 pb-4">
            <Card className="p-3 bg-slate-800/30 border-slate-700">
              <div className="flex items-center gap-2">
                <PiggyBank className="w-4 h-4 text-emerald-400" />
                <div>
                  <h4 className="font-medium text-white text-sm">Passive Income Guarantee</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    All plans offer guaranteed returns with automatic daily payouts
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>

        <BottomNavigation />
      </div>
    </ProtectedRoute>
  )
}
