"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import BottomNavigation from "@/components/bottom-navigation"
import { Search, TrendingDown, ArrowLeft, MoreHorizontal } from "lucide-react"
import Link from "next/link"
import { ProtectedRoute } from "@/components/protected-route"

export default function MarketPage() {
  const [activeCategory, setActiveCategory] = useState("spot")
  const [activeFilter, setActiveFilter] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")

  const marketData = [
    {
      symbol: "ETH",
      pair: "ETH/USDT",
      price: "4,416.62",
      change: "+2.00%",
      volume: "1.37B",
      positive: true,
      prevPrice: "$4,417.40",
    },
    {
      symbol: "BTC",
      pair: "BTC/USDT",
      price: "114,312.11",
      change: "+0.50%",
      volume: "828.8M",
      positive: true,
      prevPrice: "$114,332.49",
    },
    {
      symbol: "SOL",
      pair: "SOL/USDT",
      price: "226.04",
      change: "+1.74%",
      volume: "170.34M",
      positive: true,
      prevPrice: "$226.08",
      tag: "Solana",
    },
    {
      symbol: "BONK",
      pair: "BONK/USDT",
      price: "0.00003421",
      change: "+15.67%",
      volume: "89.2M",
      positive: true,
      prevPrice: "$0.000034",
      tag: "Meme",
    },
    {
      symbol: "WIF",
      pair: "WIF/USDT",
      price: "3.42",
      change: "+8.91%",
      volume: "156.7M",
      positive: true,
      prevPrice: "$3.41",
      tag: "Meme",
    },
    {
      symbol: "PEPE",
      pair: "PEPE/USDT",
      price: "0.00002156",
      change: "+12.34%",
      volume: "234.5M",
      positive: true,
      prevPrice: "$0.000021",
      tag: "Meme",
    },
    {
      symbol: "SHIB",
      pair: "SHIB/USDT",
      price: "0.00002789",
      change: "-2.45%",
      volume: "178.9M",
      positive: false,
      prevPrice: "$0.000028",
      tag: "Meme",
    },
    {
      symbol: "DOGE",
      pair: "DOGE/USDT",
      price: "0.38456",
      change: "+5.67%",
      volume: "445.2M",
      positive: true,
      prevPrice: "$0.384",
      tag: "Meme",
    },
    {
      symbol: "JUP",
      pair: "JUP/USDT",
      price: "1.23",
      change: "+7.89%",
      volume: "67.8M",
      positive: true,
      prevPrice: "$1.22",
      tag: "Solana",
    },
    {
      symbol: "RAY",
      pair: "RAY/USDT",
      price: "5.67",
      change: "+4.32%",
      volume: "45.6M",
      positive: true,
      prevPrice: "$5.66",
      tag: "Solana",
    },
    {
      symbol: "ORCA",
      pair: "ORCA/USDT",
      price: "4.89",
      change: "+3.21%",
      volume: "23.4M",
      positive: true,
      prevPrice: "$4.88",
      tag: "Solana",
    },
    {
      symbol: "FLOKI",
      pair: "FLOKI/USDT",
      price: "0.000234",
      change: "+18.45%",
      volume: "156.8M",
      positive: true,
      prevPrice: "$0.000233",
      tag: "Meme",
    },
    {
      symbol: "BABYDOGE",
      pair: "BABYDOGE/USDT",
      price: "0.00000345",
      change: "+22.67%",
      volume: "89.3M",
      positive: true,
      prevPrice: "$0.0000034",
      tag: "Meme",
    },
    {
      symbol: "SAMO",
      pair: "SAMO/USDT",
      price: "0.0234",
      change: "+9.87%",
      volume: "34.5M",
      positive: true,
      prevPrice: "$0.0233",
      tag: "Solana",
    },
    {
      symbol: "COPE",
      pair: "COPE/USDT",
      price: "0.456",
      change: "-1.23%",
      volume: "12.7M",
      positive: false,
      prevPrice: "$0.457",
      tag: "Solana",
    },
    {
      symbol: "STEP",
      pair: "STEP/USDT",
      price: "0.089",
      change: "+6.78%",
      volume: "8.9M",
      positive: true,
      prevPrice: "$0.088",
      tag: "Solana",
    },
    {
      symbol: "SAFEMOON",
      pair: "SAFEMOON/USDT",
      price: "0.00000089",
      change: "+45.67%",
      volume: "234.6M",
      positive: true,
      prevPrice: "$0.00000088",
      tag: "Meme",
    },
    {
      symbol: "AKITA",
      pair: "AKITA/USDT",
      price: "0.00000156",
      change: "+28.34%",
      volume: "67.8M",
      positive: true,
      prevPrice: "$0.00000155",
      tag: "Meme",
    },
    {
      symbol: "BOOST",
      pair: "BOOST/USDT",
      price: "0.099933",
      change: "+3.16%",
      volume: "111.74M",
      positive: true,
      prevPrice: "$0.09",
      tag: "CandyBomb",
    },
    {
      symbol: "XRP",
      pair: "XRP/USDT",
      price: "3.0127",
      change: "+1.16%",
      volume: "97.96M",
      positive: true,
      prevPrice: "$3.01",
    },
    {
      symbol: "MYX",
      pair: "MYX/USDT",
      price: "12.0580",
      change: "-22.38%",
      volume: "89.68M",
      positive: false,
      prevPrice: "$12.06",
    },
  ]

  const futuresData = [
    { symbol: "BTCUSDT", price: "114,350.2", change: "+0.52%", volume: "2.1B", funding: "0.0100%", positive: true },
    { symbol: "ETHUSDT", price: "4,420.15", change: "+2.05%", volume: "1.8B", funding: "0.0085%", positive: true },
    { symbol: "SOLUSDT", price: "226.89", change: "+1.80%", volume: "890M", funding: "0.0120%", positive: true },
    { symbol: "ADAUSDT", price: "1.2367", change: "+5.71%", volume: "456M", funding: "0.0095%", positive: true },
  ]

  const commodityData = [
    { symbol: "GOLD", pair: "XAU/USD", price: "2,045.67", change: "+0.85%", volume: "234M", positive: true },
    { symbol: "SILVER", pair: "XAG/USD", price: "24.56", change: "-0.32%", volume: "156M", positive: false },
    { symbol: "OIL", pair: "WTI/USD", price: "78.45", change: "+1.23%", volume: "189M", positive: true },
    { symbol: "GAS", pair: "NG/USD", price: "3.45", change: "-2.15%", volume: "98M", positive: false },
  ]

  const getCurrentData = () => {
    switch (activeCategory) {
      case "futures":
        return futuresData
      case "commodity":
        return commodityData
      default:
        return marketData
    }
  }

  const filteredData = getCurrentData().filter((item) => {
    const matchesSearch =
      item.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.pair && item.pair.toLowerCase().includes(searchQuery.toLowerCase()))

    if (activeFilter === "gainers") return item.positive && matchesSearch
    if (activeFilter === "losers") return !item.positive && matchesSearch
    if (activeFilter === "meme") return item.tag === "Meme" && matchesSearch
    if (activeFilter === "solana") return item.tag === "Solana" && matchesSearch
    return matchesSearch
  })

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-slate-950 text-white pb-20">
        {/* Header */}
        <div className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur border-b border-slate-800">
          <div className="flex items-center gap-3 p-3">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-3 h-3 text-slate-400" />
                <Input
                  placeholder="Search coins..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-400 focus:border-slate-600 text-sm h-9"
                />
              </div>
            </div>
            <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="space-y-3">
          {/* Top Navigation Tabs */}
          <div className="px-3 pt-3">
            <div className="flex gap-4 border-b border-slate-800">
              {[
                { id: "favorites", label: "Favorites" },
                { id: "markets", label: "Markets", active: true },
                { id: "onchain", label: "Onchain" },
                { id: "opportunities", label: "Opportunities" },
              ].map((tab) => (
                <Button
                  key={tab.id}
                  variant="ghost"
                  className={`pb-2 px-0 rounded-none border-b-2 text-sm ${
                    tab.active ? "border-white text-white" : "border-transparent text-slate-400 hover:text-white"
                  }`}
                >
                  {tab.label}
                  {tab.active && <div className="w-1 h-1 bg-cyan-400 rounded-full ml-2" />}
                </Button>
              ))}
            </div>
          </div>

          {/* Category Tabs */}
          <div className="px-3">
            <div className="flex gap-4 border-b border-slate-800">
              {[
                { id: "spot", label: "Spot", active: activeCategory === "spot" },
                { id: "futures", label: "Futures", active: activeCategory === "futures" },
                { id: "margin", label: "Margin", active: activeCategory === "margin" },
              ].map((category) => (
                <Button
                  key={category.id}
                  variant="ghost"
                  onClick={() => setActiveCategory(category.id)}
                  className={`pb-2 px-0 rounded-none border-b-2 text-sm ${
                    category.active ? "border-white text-white" : "border-transparent text-slate-400 hover:text-white"
                  }`}
                >
                  {category.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Filter Tabs */}
          <div className="px-3">
            <div className="flex gap-2 overflow-x-auto">
              {[
                { id: "all", label: "All" },
                { id: "gainers", label: "Gainers" },
                { id: "losers", label: "Losers" },
                { id: "meme", label: "Meme" },
                { id: "solana", label: "Solana" },
                { id: "ai", label: "AI" },
                { id: "zerofees", label: "0 fees" },
              ].map((filter) => (
                <Button
                  key={filter.id}
                  variant={activeFilter === filter.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActiveFilter(filter.id)}
                  className={`text-xs whitespace-nowrap h-7 ${
                    activeFilter === filter.id
                      ? "bg-slate-700 text-white border-slate-600"
                      : "bg-transparent border-slate-700 text-slate-400 hover:text-white hover:border-slate-600"
                  }`}
                >
                  {filter.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Market List Header */}
          <div className="flex items-center justify-between text-xs text-slate-400 px-3">
            <div className="flex items-center gap-2">
              <span>Coin/Volume</span>
              <TrendingDown className="w-3 h-3" />
            </div>
            <div className="flex gap-12">
              <span>Price</span>
              <span>Change</span>
            </div>
          </div>

          {/* Market List */}
          <div className="bg-slate-950">
            {filteredData.map((item, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 hover:bg-slate-900/50 cursor-pointer transition-colors border-b border-slate-900/50"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-slate-700 to-slate-800 rounded-full flex items-center justify-center border border-slate-600">
                    <span className="font-bold text-xs">{item.symbol.slice(0, 2)}</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{item.symbol}</span>
                      <span className="text-slate-400 text-xs">/ USDT</span>
                      {item.tag && (
                        <Badge
                          className={`text-xs px-1 py-0 ${
                            item.tag === "Meme"
                              ? "bg-pink-500/20 text-pink-400 border-pink-500/30"
                              : item.tag === "Solana"
                                ? "bg-purple-500/20 text-purple-400 border-purple-500/30"
                                : "bg-cyan-500/20 text-cyan-400 border-cyan-500/30"
                          }`}
                        >
                          {item.tag}
                        </Badge>
                      )}
                    </div>
                    <div className="text-xs text-slate-400">{item.volume}</div>
                  </div>
                </div>
                <div className="flex items-center gap-8">
                  <div className="text-right">
                    <div className="font-medium text-sm">{item.price}</div>
                    <div className="text-xs text-slate-400">{item.prevPrice}</div>
                  </div>
                  <div className="text-right min-w-[60px]">
                    <Badge
                      className={`text-xs font-medium px-2 py-0 ${
                        item.positive
                          ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                          : "bg-red-500/20 text-red-400 border-red-500/30"
                      }`}
                    >
                      {item.change}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <BottomNavigation />
      </div>
    </ProtectedRoute>
  )
}
