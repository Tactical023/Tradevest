import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, DollarSign, TrendingUp, Activity, UserCheck, Wallet, PieChart } from "lucide-react"

export default async function AdminDashboard() {
  const supabase = await createClient()

  // Check if user is authenticated and is admin
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user profile to check admin status
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile?.is_admin) {
    redirect("/")
  }

  // Fetch dashboard statistics
  const [
    { count: totalUsers },
    { count: verifiedUsers },
    { count: activeInvestments },
    { data: recentUsers },
    { data: topInvestors },
    { data: totalBalances },
  ] = await Promise.all([
    supabase.from("profiles").select("*", { count: "exact", head: true }),
    supabase.from("profiles").select("*", { count: "exact", head: true }).eq("is_verified", true),
    supabase.from("investments").select("*", { count: "exact", head: true }).eq("status", "active"),
    supabase
      .from("profiles")
      .select("id, full_name, email, created_at, balance, is_verified")
      .order("created_at", { ascending: false })
      .limit(5),
    supabase
      .from("profiles")
      .select("id, full_name, email, total_invested, total_profit")
      .order("total_invested", { ascending: false })
      .limit(5),
    supabase.rpc("get_total_balances"),
  ])

  const totalBalance = totalBalances?.[0]?.total_balance || 0
  const totalInvested = totalBalances?.[0]?.total_invested || 0
  const totalProfit = totalBalances?.[0]?.total_profit || 0

  return (
    <div className="min-h-screen bg-slate-900 text-white p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">
              Admin Dashboard
            </h1>
            <p className="text-slate-400 mt-2">Manage your TradeVest platform</p>
          </div>
          <Badge variant="secondary" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
            Administrator
          </Badge>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-200">Total Users</CardTitle>
              <Users className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{totalUsers || 0}</div>
              <p className="text-xs text-slate-400">
                {verifiedUsers || 0} verified ({(((verifiedUsers || 0) / (totalUsers || 1)) * 100).toFixed(1)}%)
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-200">Total Balance</CardTitle>
              <DollarSign className="h-4 w-4 text-emerald-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">${totalBalance?.toLocaleString() || "0"}</div>
              <p className="text-xs text-slate-400">Platform total balance</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-200">Total Invested</CardTitle>
              <TrendingUp className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">${totalInvested?.toLocaleString() || "0"}</div>
              <p className="text-xs text-slate-400">Active investments</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-200">Active Investments</CardTitle>
              <Activity className="h-4 w-4 text-orange-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{activeInvestments || 0}</div>
              <p className="text-xs text-slate-400">Currently running</p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Users */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <UserCheck className="h-5 w-5 text-blue-400" />
                Recent Users
              </CardTitle>
              <CardDescription className="text-slate-400">Latest user registrations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentUsers?.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full flex items-center justify-center text-xs font-bold">
                        {user.full_name?.charAt(0) || user.email.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">{user.full_name || "No Name"}</p>
                        <p className="text-xs text-slate-400">{user.email}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge
                        variant={user.is_verified ? "default" : "secondary"}
                        className={
                          user.is_verified
                            ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                            : "bg-slate-600/20 text-slate-400 border-slate-600/30"
                        }
                      >
                        {user.is_verified ? "Verified" : "Pending"}
                      </Badge>
                      <p className="text-xs text-slate-400 mt-1">${user.balance?.toFixed(2) || "0.00"}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Top Investors */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <PieChart className="h-5 w-5 text-emerald-400" />
                Top Investors
              </CardTitle>
              <CardDescription className="text-slate-400">Highest investment amounts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topInvestors?.map((investor, index) => (
                  <div key={investor.id} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-xs font-bold">
                        #{index + 1}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">{investor.full_name || "Anonymous"}</p>
                        <p className="text-xs text-slate-400">{investor.email}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-emerald-400">
                        ${investor.total_invested?.toLocaleString() || "0"}
                      </p>
                      <p className="text-xs text-slate-400">
                        Profit: ${investor.total_profit?.toLocaleString() || "0"}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Quick Actions</CardTitle>
            <CardDescription className="text-slate-400">Common administrative tasks</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg hover:bg-blue-500/20 transition-colors cursor-pointer">
                <Users className="h-8 w-8 text-blue-400 mb-2" />
                <h3 className="font-semibold text-white">Manage Users</h3>
                <p className="text-sm text-slate-400">View and manage user accounts</p>
              </div>

              <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-lg hover:bg-emerald-500/20 transition-colors cursor-pointer">
                <Wallet className="h-8 w-8 text-emerald-400 mb-2" />
                <h3 className="font-semibold text-white">Manage Investments</h3>
                <p className="text-sm text-slate-400">Monitor investment plans</p>
              </div>

              <div className="p-4 bg-purple-500/10 border border-purple-500/20 rounded-lg hover:bg-purple-500/20 transition-colors cursor-pointer">
                <Activity className="h-8 w-8 text-purple-400 mb-2" />
                <h3 className="font-semibold text-white">System Analytics</h3>
                <p className="text-sm text-slate-400">View platform statistics</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
