import type React from "react"
import { AdminNav } from "@/components/admin-nav"
import { ProtectedRoute } from "@/components/protected-route"

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <ProtectedRoute requireAdmin>
      <div className="min-h-screen bg-slate-900">
        <AdminNav />
        {children}
      </div>
    </ProtectedRoute>
  )
}
