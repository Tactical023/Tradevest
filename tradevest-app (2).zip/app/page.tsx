"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import BottomNavigation from "@/components/bottom-navigation"
import { UserMenu } from "@/components/user-menu"
import { useAuth } from "@/components/auth-provider"
import Link from "next/link"
import {
  Plus,
  Eye,
  EyeOff,
  Trophy,
  Users,
  Gift,
  ChevronRight,
  TrendingUp,
  Bell,
  Settings,
  BarChart3,
} from "lucide-react"

export default function TradeVestHome() {
  const { user, profile, loading } = useAuth()
  const [balanceVisible, setBalanceVisible] = useState(true)
  const [currentBanner, setCurrentBanner] = useState(0)

  const banners = [
    {
      title: "$200,000 USD CAMPAIGN",
      subtitle: "Join the exclusive campaign for top 1,000 participants. Limited time offer with guaranteed rewards.",
      color: "bg-gradient-to-r from-amber-500 via-yellow-500 to-orange-500",
      icon: <Trophy className="w-6 h-6" />,
      link: "/rewards",
    },
    {
      title: "PROFESSIONAL TRADING TOOLS",
      subtitle: "Advanced charting, real-time analytics, and institutional-grade trading features now available.",
      color: "bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600",
      icon: <BarChart3 className="w-6 h-6" />,
      link: "/market",
    },
    {
      title: "PASSIVE INCOME SOLUTIONS",
      subtitle: "Earn up to 15% daily ROI with our automated investment strategies. Zero trading experience required.",
      color: "bg-gradient-to-r from-emerald-500 via-green-500 to-teal-500",
      icon: <TrendingUp className="w-6 h-6" />,
      link: "/earnings",
    },
    {
      title: "REFERRAL REWARDS PROGRAM",
      subtitle: "Earn up to $1,000 per qualified referral. Join our affiliate program for influencers and traders.",
      color: "bg-gradient-to-r from-pink-500 via-rose-500 to-red-500",
      icon: <Users className="w-6 h-6" />,
      link: "/referral",
    },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % banners.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [banners.length])

  const topMovers = [
    {
      symbol: "BTC",
      name: "Bitcoin",
      price: "114,312.11",
      change: "+0.50%",
      positive: true,
      volume: "828.8M",
      rank: 1,
    },
    { symbol: "ETH", name: "Ethereum", price: "4,416.62", change: "+2.00%", positive: true, volume: "1.37B", rank: 2 },
    { symbol: "SOL", name: "Solana", price: "226.04", change: "+1.74%", positive: true, volume: "170.34M", rank: 5 },
    { symbol: "BNB", name: "BNB Chain", price: "712.45", change: "+2.31%", positive: true, volume: "1.2B", rank: 4 },
    { symbol: "BONK", name: "Bonk", price: "0.00003421", change: "+15.67%", positive: true, volume: "89.2M", rank: 67 },
    { symbol: "JUP", name: "Jupiter", price: "1.23", change: "+7.89%", positive: true, volume: "67.8M", rank: 89 },
    { symbol: "RAY", name: "Raydium", price: "5.67", change: "+4.32%", positive: true, volume: "45.6M", rank: 156 },
    {
      symbol: "PEPE",
      name: "Pepe",
      price: "0.00002156",
      change: "+12.34%",
      positive: true,
      volume: "234.5M",
      rank: 23,
    },
  ]

  const featuredVestingPlans = [
    {
      name: "Silver Plan",
      apr: "3.5%",
      duration: "7 days",
      minAmount: "$5",
      maxAmount: "$100",
      slots: "2,000",
      icon: "🥈",
    },
    {
      name: "Golden Plan",
      apr: "5.0%",
      duration: "30 days",
      minAmount: "$100",
      maxAmount: "$10K",
      slots: "500",
      icon: "🥇",
    },
    {
      name: "Diamond Plan",
      apr: "15.0%",
      duration: "180 days",
      minAmount: "$1K",
      maxAmount: "$1M",
      slots: "109",
      icon: "💎",
    },
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-white pb-20">
      {/* Enhanced Header */}
      <div className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur border-b border-slate-800">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-amber-500 to-orange-500 rounded-xl flex items-center justify-center shadow-lg">
              <span className="font-bold text-lg text-white">T</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">TradeVest</h1>
              <p className="text-xs text-slate-400">Professional Trading Platform</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {user && (
              <>
                <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white relative">
                  <Bell className="w-5 h-5" />
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></div>
                </Button>
                <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                  <Settings className="w-5 h-5" />
                </Button>
              </>
            )}
            <UserMenu />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-4 space-y-6">
        {/* Enhanced Balance Section */}
        <Card className="p-6 bg-gradient-to-br from-slate-900/80 to-slate-800/50 border-slate-700 backdrop-blur shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="text-slate-300 font-medium">
                {user ? `${profile?.full_name ? `${profile.full_name}'s` : "Your"} Portfolio` : "Total Portfolio Value"}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setBalanceVisible(!balanceVisible)}
                className="p-1 h-auto text-slate-400 hover:text-white"
              >
                {balanceVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              </Button>
            </div>
            <Button
              size="sm"
              className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white border-0 shadow-lg"
              disabled={!user}
            >
              <Plus className="w-4 h-4 mr-1" />
              Deposit
            </Button>
          </div>
          <div className="text-4xl font-bold mb-2 text-white">
            {balanceVisible ? (user ? `$${profile?.balance?.toFixed(2) || "0.00"}` : "$12,345.67") : "••••••••"}
          </div>
          <div className="flex items-center gap-4 text-sm">
            <span className="text-slate-400">≈ {balanceVisible ? "0.108 BTC" : "•••••••"}</span>
            <Badge className="bg-emerald-600/30 text-emerald-300 border-emerald-500/50">+2.34% (24h)</Badge>
          </div>
          {!user && (
            <div className="mt-4 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <p className="text-sm text-blue-300">
                <Link href="/auth/login" className="font-medium hover:underline">
                  Sign in
                </Link>{" "}
                to view your real portfolio and start trading
              </p>
            </div>
          )}
        </Card>

        {/* Enhanced Action Buttons */}
        <div className="grid grid-cols-4 gap-3">
          {[
            {
              icon: <Gift className="w-5 h-5" />,
              label: "Rewards",
              color: "bg-purple-600/30 border-purple-400/50",
              textColor: "text-purple-300",
              href: "/rewards",
            },
            {
              icon: <Users className="w-5 h-5" />,
              label: "Referral",
              color: "bg-blue-600/30 border-blue-400/50",
              textColor: "text-blue-300",
              href: "/referral",
            },
            {
              icon: <TrendingUp className="w-5 h-5" />,
              label: "Earn",
              color: "bg-emerald-600/30 border-emerald-400/50",
              textColor: "text-emerald-300",
              href: "/earnings",
            },
            {
              icon: <BarChart3 className="w-5 h-5" />,
              label: "Invest",
              color: "bg-amber-600/30 border-amber-400/50",
              textColor: "text-amber-300",
              href: "/investing",
            },
          ].map((action, index) => (
            <Link key={index} href={action.href}>
              <Button
                variant="outline"
                className={`flex flex-col gap-2 h-16 ${action.color} border ${action.textColor} hover:bg-opacity-40 transition-all duration-200 hover:scale-105`}
              >
                {action.icon}
                <span className="text-xs font-medium">{action.label}</span>
              </Button>
            </Link>
          ))}
        </div>

        {/* Enhanced Rotating Banner */}
        <Link href={banners[currentBanner].link}>
          <Card
            className={`p-5 ${banners[currentBanner].color} text-white border-0 cursor-pointer hover:scale-[1.02] transition-all duration-300 shadow-xl`}
          >
            <div className="flex items-center gap-4">
              <div className="p-2 bg-white/20 rounded-lg backdrop-blur">{banners[currentBanner].icon}</div>
              <div className="flex-1">
                <h3 className="font-bold text-lg mb-1">{banners[currentBanner].title}</h3>
                <p className="text-sm opacity-90 leading-relaxed">{banners[currentBanner].subtitle}</p>
              </div>
              <ChevronRight className="w-6 h-6 opacity-70" />
            </div>
            {/* Banner indicators */}
            <div className="flex justify-center gap-2 mt-4">
              {banners.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all ${
                    index === currentBanner ? "bg-white" : "bg-white/40"
                  }`}
                />
              ))}
            </div>
          </Card>
        </Link>

        {/* Enhanced Top Movers */}
        <Card className="p-5 bg-slate-900/50 border-slate-800 backdrop-blur shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-lg text-white">Market Leaders</h3>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="text-xs bg-emerald-600/30 border-emerald-400/50 text-emerald-300 hover:bg-emerald-600/40"
              >
                Gainers
              </Button>
              <Button variant="ghost" size="sm" className="text-xs text-slate-400 hover:text-white">
                Volume
              </Button>
            </div>
          </div>
          <div className="space-y-3">
            {topMovers.slice(0, 6).map((coin, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 rounded-lg hover:bg-slate-800/30 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 font-medium w-6">#{coin.rank}</span>
                    <div className="w-10 h-10 bg-gradient-to-br from-slate-700 to-slate-800 rounded-full flex items-center justify-center border border-slate-600">
                      <span className="text-sm font-bold text-white">{coin.symbol.slice(0, 2)}</span>
                    </div>
                  </div>
                  <div>
                    <div className="font-medium text-white">{coin.symbol}/USDT</div>
                    <div className="text-xs text-slate-400">Vol: {coin.volume}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-white">${coin.price}</div>
                  <Badge
                    variant={coin.positive ? "default" : "destructive"}
                    className={`text-xs ${
                      coin.positive
                        ? "bg-emerald-600/30 text-emerald-300 border-emerald-400/50"
                        : "bg-red-600/30 text-red-300 border-red-400/50"
                    }`}
                  >
                    {coin.change}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
          <Link href="/market">
            <Button variant="ghost" className="w-full mt-4 text-slate-400 hover:text-white">
              View All Markets <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </Card>

        {/* Enhanced Vesting Plans Preview */}
        <Card className="p-5 bg-slate-900/50 border-slate-800 backdrop-blur shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-lg text-white">Investment Plans</h3>
            <Link href="/earnings">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                View All <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </div>
          <div className="space-y-3">
            {featuredVestingPlans.slice(0, 2).map((plan, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 rounded-lg bg-gradient-to-r from-slate-800/50 to-slate-700/30 border border-slate-700/50 hover:border-slate-600/50 transition-all cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="text-2xl">{plan.icon}</div>
                  <div>
                    <h4 className="font-medium text-white">{plan.name}</h4>
                    <p className="text-xs text-slate-400">
                      {plan.duration} • {plan.minAmount} - {plan.maxAmount}
                    </p>
                    <p className="text-xs text-slate-500">{plan.slots} slots available</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold text-emerald-300">{plan.apr}</div>
                  <div className="text-xs text-slate-400 mb-2">Daily ROI</div>
                  <Button
                    size="sm"
                    className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white text-xs shadow-lg"
                  >
                    Invest Now
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <BottomNavigation />
    </div>
  )
}
