"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import BottomNavigation from "@/components/bottom-navigation"
import {
  ArrowLeft,
  Eye,
  EyeOff,
  TrendingUp,
  TrendingDown,
  Search,
  Filter,
  MoreHorizontal,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  BarChart3,
  PieChart,
  Wallet,
  History,
} from "lucide-react"
import Link from "next/link"
import { ProtectedRoute } from "@/components/protected-route"

export default function AssetsPage() {
  const [balanceVisible, setBalanceVisible] = useState(true)
  const [activeTab, setActiveTab] = useState("overview")
  const [searchQuery, setSearchQuery] = useState("")

  const portfolioData = {
    totalBalance: 12345.67,
    totalBalanceBTC: 0.108,
    pnl24h: 234.56,
    pnl24hPercent: 1.95,
    spotBalance: 8234.56,
    futuresBalance: 3456.78,
    stakingBalance: 654.33,
  }

  const holdings = [
    {
      symbol: "BTC",
      name: "Bitcoin",
      balance: "0.0856",
      usdValue: "9,789.45",
      change24h: "+2.34%",
      positive: true,
      allocation: 79.2,
    },
    {
      symbol: "ETH",
      name: "Ethereum",
      balance: "0.5678",
      usdValue: "2,508.92",
      change24h: "+1.87%",
      positive: true,
      allocation: 20.3,
    },
    {
      symbol: "SOL",
      name: "Solana",
      balance: "1.2345",
      usdValue: "279.12",
      change24h: "+3.45%",
      positive: true,
      allocation: 2.3,
    },
    {
      symbol: "USDT",
      name: "Tether",
      balance: "156.78",
      usdValue: "156.78",
      change24h: "0.00%",
      positive: true,
      allocation: 1.3,
    },
  ]

  const transactions = [
    {
      type: "deposit",
      asset: "USDT",
      amount: "+500.00",
      time: "2 hours ago",
      status: "Completed",
    },
    {
      type: "trade",
      asset: "BTC/USDT",
      amount: "+0.0123 BTC",
      time: "5 hours ago",
      status: "Completed",
    },
    {
      type: "withdrawal",
      asset: "ETH",
      amount: "-0.1234 ETH",
      time: "1 day ago",
      status: "Completed",
    },
    {
      type: "staking",
      asset: "SOL",
      amount: "+1.2345 SOL",
      time: "2 days ago",
      status: "Completed",
    },
  ]

  const filteredHoldings = holdings.filter(
    (holding) =>
      holding.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      holding.name.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-slate-950 text-white pb-20">
        {/* Header */}
        <div className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur border-b border-slate-800">
          <div className="flex items-center gap-3 p-3">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <h1 className="text-lg font-bold">Assets</h1>
            <div className="ml-auto flex items-center gap-2">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <BarChart3 className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {/* Portfolio Overview */}
          <div className="p-3">
            <Card className="p-4 bg-slate-900/50 border-slate-700">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 text-sm">Total balance</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setBalanceVisible(!balanceVisible)}
                    className="p-1 h-auto text-slate-400 hover:text-white"
                  >
                    {balanceVisible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                  </Button>
                </div>
                <PieChart className="w-4 h-4 text-slate-400" />
              </div>

              <div className="space-y-2">
                <div className="text-3xl font-bold text-white">
                  {balanceVisible ? `$${portfolioData.totalBalance.toLocaleString()}` : "••••••••"}
                </div>
                <div className="text-sm text-slate-400">
                  ≈ {balanceVisible ? `${portfolioData.totalBalanceBTC} BTC` : "•••••••"}
                </div>
                <div className="flex items-center gap-2">
                  <Badge
                    className={`text-xs ${
                      portfolioData.pnl24hPercent > 0
                        ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                        : "bg-red-500/20 text-red-400 border-red-500/30"
                    }`}
                  >
                    {portfolioData.pnl24hPercent > 0 ? (
                      <TrendingUp className="w-3 h-3 mr-1" />
                    ) : (
                      <TrendingDown className="w-3 h-3 mr-1" />
                    )}
                    {portfolioData.pnl24hPercent > 0 ? "+" : ""}
                    {portfolioData.pnl24hPercent}%
                  </Badge>
                  <span className="text-sm text-slate-400">
                    {balanceVisible
                      ? `${portfolioData.pnl24hPercent > 0 ? "+" : ""}$${portfolioData.pnl24h}`
                      : "••••••"}{" "}
                    (24h)
                  </span>
                </div>
              </div>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="px-3">
            <div className="grid grid-cols-4 gap-2">
              {[
                { icon: <Plus className="w-4 h-4" />, label: "Add funds", primary: true },
                { icon: <ArrowUpRight className="w-4 h-4" />, label: "Withdraw" },
                { icon: <ArrowDownRight className="w-4 h-4" />, label: "Transfer" },
                { icon: <TrendingUp className="w-4 h-4" />, label: "PnL" },
              ].map((action, index) => (
                <Button
                  key={index}
                  variant={action.primary ? "default" : "outline"}
                  className={`flex flex-col gap-1 h-14 text-xs ${
                    action.primary
                      ? "bg-white text-slate-900 hover:bg-slate-100"
                      : "bg-slate-800/50 border-slate-700 text-slate-300 hover:bg-slate-700/50"
                  }`}
                >
                  {action.icon}
                  <span>{action.label}</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Account Breakdown */}
          <div className="px-3">
            <Card className="p-3 bg-slate-900/50 border-slate-700">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-white text-sm">Account</h3>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                    <BarChart3 className="w-3 h-3" />
                  </Button>
                  <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                    <Filter className="w-3 h-3" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-slate-800/50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="font-medium text-white text-sm">Spot</span>
                  </div>
                  <span className="font-medium text-white text-sm">
                    {balanceVisible ? `$${portfolioData.spotBalance.toLocaleString()}` : "••••••"}
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 bg-slate-800/50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                    <span className="font-medium text-white text-sm">Futures</span>
                  </div>
                  <span className="font-medium text-white text-sm">
                    {balanceVisible ? `$${portfolioData.futuresBalance.toLocaleString()}` : "••••••"}
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 bg-slate-800/50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <span className="font-medium text-white text-sm">Staking</span>
                  </div>
                  <span className="font-medium text-white text-sm">
                    {balanceVisible ? `$${portfolioData.stakingBalance.toLocaleString()}` : "••••••"}
                  </span>
                </div>
              </div>
            </Card>
          </div>

          {/* Navigation Tabs */}
          <div className="px-3">
            <div className="flex gap-2 overflow-x-auto">
              {[
                { id: "overview", label: "Overview", icon: <Wallet className="w-3 h-3" /> },
                { id: "spot", label: "Spot" },
                { id: "futures", label: "Futures" },
                { id: "staking", label: "Staking" },
                { id: "history", label: "History", icon: <History className="w-3 h-3" /> },
              ].map((tab) => (
                <Button
                  key={tab.id}
                  variant={activeTab === tab.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActiveTab(tab.id)}
                  className={`text-xs whitespace-nowrap h-8 ${
                    activeTab === tab.id
                      ? "bg-white text-slate-900"
                      : "bg-slate-800/50 border-slate-700 text-slate-400 hover:text-white hover:bg-slate-700/50"
                  }`}
                >
                  {tab.icon && <span className="mr-1">{tab.icon}</span>}
                  {tab.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Search Bar */}
          {activeTab !== "history" && (
            <div className="px-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-3 h-3 text-slate-400" />
                <Input
                  placeholder="Search assets..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-400 focus:border-slate-600 text-sm h-9"
                />
              </div>
            </div>
          )}

          {/* Content based on active tab */}
          {(activeTab === "overview" || activeTab === "spot") && (
            <div className="px-3 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-white text-sm">Holdings</h3>
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <span className="text-xs">USD Value</span>
                  <TrendingUp className="w-3 h-3" />
                </div>
              </div>

              <div className="bg-slate-950">
                {filteredHoldings.map((holding, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 hover:bg-slate-900/50 cursor-pointer transition-colors border-b border-slate-900/50"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-slate-700 to-slate-800 rounded-full flex items-center justify-center border border-slate-600">
                        <span className="font-bold text-xs">{holding.symbol.slice(0, 2)}</span>
                      </div>
                      <div>
                        <div className="font-medium text-white text-sm">{holding.symbol}</div>
                        <div className="text-xs text-slate-400">{holding.name}</div>
                        <div className="text-xs text-slate-500">{holding.balance}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium text-white text-sm">
                        {balanceVisible ? `$${holding.usdValue}` : "••••••"}
                      </div>
                      <Badge
                        className={`text-xs ${
                          holding.positive
                            ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                            : "bg-red-500/20 text-red-400 border-red-500/30"
                        }`}
                      >
                        {holding.change24h}
                      </Badge>
                      <div className="text-xs text-slate-500 mt-1">{holding.allocation}%</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "futures" && (
            <div className="px-3 space-y-3">
              <Card className="p-4 bg-slate-900/50 border-slate-700 text-center">
                <div className="text-slate-400 mb-2 text-sm">Futures Balance</div>
                <div className="text-2xl font-bold text-white">
                  {balanceVisible ? `$${portfolioData.futuresBalance.toLocaleString()}` : "••••••••"}
                </div>
                <div className="text-sm text-slate-400 mt-2">Available for trading</div>
                <Button className="mt-3 bg-white text-slate-900 hover:bg-slate-100 text-sm">
                  Start Futures Trading
                </Button>
              </Card>

              <Card className="p-3 bg-slate-900/50 border-slate-700">
                <h4 className="font-medium mb-3 text-white text-sm">Open Positions</h4>
                <div className="text-center text-slate-400 py-6">
                  <div className="text-sm">No open positions</div>
                  <div className="text-xs mt-1">Your futures positions will appear here</div>
                </div>
              </Card>
            </div>
          )}

          {activeTab === "staking" && (
            <div className="px-3 space-y-3">
              <Card className="p-4 bg-slate-900/50 border-slate-700 text-center">
                <div className="text-slate-400 mb-2 text-sm">Staking Balance</div>
                <div className="text-2xl font-bold text-white">
                  {balanceVisible ? `$${portfolioData.stakingBalance.toLocaleString()}` : "••••••••"}
                </div>
                <div className="text-sm text-slate-400 mt-2">Earning rewards</div>
                <Link href="/earnings">
                  <Button className="mt-3 bg-white text-slate-900 hover:bg-slate-100 text-sm">
                    View Staking Options
                  </Button>
                </Link>
              </Card>

              <Card className="p-3 bg-slate-900/50 border-slate-700">
                <h4 className="font-medium mb-3 text-white text-sm">Active Stakes</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-2 bg-slate-800/50 rounded-lg">
                    <div>
                      <div className="font-medium text-white text-sm">USDT Flexible</div>
                      <div className="text-xs text-slate-400">12.11% APR</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium text-white text-sm">1,500 USDT</div>
                      <div className="text-xs text-emerald-400">+45.67 USDT</div>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          )}

          {activeTab === "history" && (
            <div className="px-3 space-y-3">
              <h3 className="font-semibold text-white text-sm">Transaction History</h3>

              <div className="bg-slate-950">
                {transactions.map((tx, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 hover:bg-slate-900/50 cursor-pointer transition-colors border-b border-slate-900/50"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          tx.type === "deposit"
                            ? "bg-emerald-500/20"
                            : tx.type === "withdrawal"
                              ? "bg-red-500/20"
                              : tx.type === "trade"
                                ? "bg-blue-500/20"
                                : "bg-purple-500/20"
                        }`}
                      >
                        {tx.type === "deposit" ? (
                          <ArrowDownRight className="w-4 h-4 text-emerald-500" />
                        ) : tx.type === "withdrawal" ? (
                          <ArrowUpRight className="w-4 h-4 text-red-500" />
                        ) : tx.type === "trade" ? (
                          <TrendingUp className="w-4 h-4 text-blue-500" />
                        ) : (
                          <Plus className="w-4 h-4 text-purple-500" />
                        )}
                      </div>
                      <div>
                        <div className="font-medium capitalize text-white text-sm">{tx.type}</div>
                        <div className="text-xs text-slate-400">{tx.asset}</div>
                        <div className="text-xs text-slate-500">{tx.time}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div
                        className={`font-medium text-sm ${tx.amount.startsWith("+") ? "text-emerald-400" : "text-white"}`}
                      >
                        {tx.amount}
                      </div>
                      <Badge className="text-xs bg-slate-700 text-slate-300 border-slate-600">{tx.status}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <BottomNavigation />
      </div>
    </ProtectedRoute>
  )
}
