"use client"

import { Home, TrendingUp, PiggyBank, Wallet, BarChart3 } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"

export default function BottomNavigation() {
  const pathname = usePathname()

  const navItems = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/earnings", icon: PiggyBank, label: "Earnings" },
    { href: "/market", icon: TrendingUp, label: "Market" },
    { href: "/investing", icon: BarChart3, label: "Investing" },
    { href: "/assets", icon: Wallet, label: "Assets" },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-slate-950/95 backdrop-blur border-t border-slate-800">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const isActive = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                isActive ? "text-amber-400" : "text-slate-400 hover:text-white"
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
